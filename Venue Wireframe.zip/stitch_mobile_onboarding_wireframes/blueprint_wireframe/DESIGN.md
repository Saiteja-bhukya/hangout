---
name: Blueprint Wireframe
colors:
  surface: '#f6f9ff'
  surface-dim: '#d6dae0'
  surface-bright: '#f6f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f4fa'
  surface-container: '#eaeef4'
  surface-container-high: '#e5e8ee'
  surface-container-highest: '#dfe3e9'
  on-surface: '#171c20'
  on-surface-variant: '#45464c'
  inverse-surface: '#2c3136'
  inverse-on-surface: '#edf1f7'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#575e70'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#141b2b'
  on-primary-container: '#7d8497'
  inverse-primary: '#c0c6db'
  secondary: '#555f6d'
  on-secondary: '#ffffff'
  secondary-container: '#d6e0f1'
  on-secondary-container: '#596372'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#261906'
  on-tertiary-container: '#968065'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce2f7'
  primary-fixed-dim: '#c0c6db'
  on-primary-fixed: '#141b2b'
  on-primary-fixed-variant: '#404758'
  secondary-fixed: '#d9e3f4'
  secondary-fixed-dim: '#bdc7d8'
  on-secondary-fixed: '#121c28'
  on-secondary-fixed-variant: '#3e4755'
  tertiary-fixed: '#f9debf'
  tertiary-fixed-dim: '#dcc2a4'
  on-tertiary-fixed: '#261906'
  on-tertiary-fixed-variant: '#55442d'
  background: '#f6f9ff'
  on-background: '#171c20'
  surface-variant: '#dfe3e9'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: '0'
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: '0'
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  annotation:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.05em
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system establishes a strict, utilitarian low-fidelity mobile wireframing aesthetic. It prioritizes structure, hierarchy, and layout clarity over decorative styling. 

- **Personality:** Analytical, structural, deliberate, unadorned.
- **Visual Style:** Minimalist architectural wireframe. Layouts rely on flat rectangular bounding boxes, ruled lines, explicit structural dividers, and classic blueprint placeholder conventions (e.g., diagonal cross markers for images).
- **Emotional Response:** Functional clarity, neutrality, focus on workflow and information architecture without visual bias or aesthetic distraction.
- **Audience:** Product designers, engineers, and stakeholders evaluating mobile user flows and core UX mechanics.

## Colors

The palette is strictly monochromatic. Gradients, saturated tints, and decorative color fills are strictly prohibited.

- **Background Default:** `#FFFFFF` (Base canvas)
- **Surface & Container Tiers:**
  - `Surface Subdued`: `#F3F4F6` (Inactive states, canvas background offset)
  - `Surface Muted`: `#E5E7EB` (Placeholder container fills, secondary interactive zones)
- **Borders & Dividers:**
  - `Border Subtle`: `#D1D5DB` (Structural cell divisions, container outlines)
  - `Border Bold`: `#111827` (Interactive boundaries, primary bounding boxes)
- **Text & Content Hierarchy:**
  - `Text Primary`: `#111827` (Headlines, active states, key interactive labels)
  - `Text Secondary`: `#4B5563` (Body narrative, descriptive metadata)
  - `Text Annotation / Placeholder`: `#9CA3AF` (Secondary annotations, placeholder captions, disabled labels)

## Typography

Typography relies entirely on the neutral, utilitarian structure of Inter. 

- **Scale Constraints:** Tuned strictly for the 390px mobile viewport format. Maximum headline size is capped at 24px to prevent horizontal overcrowding.
- **Annotations:** Micro-labels and schematic markers use `annotation` styling, rendered in uppercase (`text-transform: uppercase`) with tracked letter spacing for diagrammatic clarity.
- **Weights:** Restricted strictly to Regular (400) for copy and Semibold (600) / Medium (500) for structural hierarchy and interactive buttons.

## Layout & Spacing

- **Viewport Dimension:** Calibrated for a canonical 390px mobile viewport width. All views anchor inside a vertical single-column stack.
- **Column System:** 4-column fluid mobile grid inside the 390px canvas, with a fixed 16px (`1rem`) outer margin and 16px (`1rem`) inter-column gutter.
- **Rhythm:** Strict 4px base increment system (`0.25rem`, `0.5rem`, `0.75rem`, `1rem`, `1.5rem`).
- **Nesting:** Structural panels sit flush with outer canvas margins or divide internally using hairline 1px borders rather than detached margin buffers.

## Elevation & Depth

- **Zero Shadows:** CSS `box-shadow` and `filter: drop-shadow()` are banned entirely.
- **Boundary Delineation:** Hierarchy and layering are communicated exclusively through 1px solid structural outlines (`#111827` or `#D1D5DB`) and flat surface tonality (`#FFFFFF`, `#F3F4F6`, `#E5E7EB`).
- **Modals & Overlays:** Sheets, bottom sheets, and alerts use an opaque white background (`#FFFFFF`) with a 1px solid `#111827` border, placed over a flat 50% opacity neutral backdrop overlay (`rgba(17, 24, 39, 0.5)`).

## Shapes

All shapes across the system have 0px border-radius (`roundedness: 0`). 

- Every container, card, modal, button, and input element is rendered with sharp 90-degree corners.
- Structural borders must measure exactly 1px solid.

## Components

### Buttons
- **Primary:** Solid `#111827` background, `#FFFFFF` text, 0px border radius, 44px min height for mobile touch standards. No shadows.
- **Secondary / Outline:** `#FFFFFF` background, 1px solid `#111827` border, `#111827` text.
- **Subtle / Ghost:** Transparent background, 1px solid `#D1D5DB` border, `#4B5563` text.

### Image & Media Placeholders
- **Box Marker:** Rectangular box with `#F3F4F6` background and 1px solid `#D1D5DB` or `#111827` border.
- **Crosshair / Diagonal Cross:** SVG/Canvas `X` connecting opposite corners with 1px stroke (`#D1D5DB`). Center features a centered wireframe label (`[IMAGE: 16:9]`) in `annotation` typography.

### Input Fields
- **Container:** Height 44px, `#FFFFFF` background, 1px solid `#111827` border (or `#D1D5DB` for resting/unfocused).
- **Placeholder Text:** Styled with `#9CA3AF`, aligned left with 12px padding.
- **Field Labels:** Positioned directly above the input container in `label-sm` uppercase.

### Checkboxes & Radio Buttons
- **Checkbox:** Square box 18x18px, 1px solid `#111827`, 0px border radius. Checked state features a centered black square or an explicit `#111827` solid fill with white checkmark.
- **Radio Button:** Square or round schematic outline (18x18px) with a centered solid black dot when selected.

### Chips & Tags
- **Structure:** Height 24px, 0px radius, 1px solid `#D1D5DB` border, `#FFFFFF` background.
- **Active State:** `#111827` background, `#FFFFFF` text, 1px solid `#111827` border.

### Cards & Grouping Containers
- **Wireframe Card:** `#FFFFFF` background, 1px solid `#D1D5DB` border, padded with `space-md`. 
- **Dividers:** 1px solid `#E5E7EB` separating internal card segments horizontally or vertically.

### Annotations & Flow Markers
- **Annotation Badge:** Inverted pill/rect tag with 1px solid `#111827`, `#F3F4F6` background, featuring index identifiers (e.g., `[01]`, `[A]`) positioned on top-right edges of containers to denote interactive flow anchors.